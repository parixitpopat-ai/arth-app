# ACC-FOUNDATION-001 — Foundation Consolidation

**Status:** Draft baseline for ACC Validation Sprint
**Not** a recovery, not a reconstruction, not an audit. Accounts architecture predates the TRX-000/HOME-000/BUD-000 modernization methodology — this document consolidates what was already decided under the earlier governance system into a single baseline the current methodology can validate against.

---

## 1. Purpose

Consolidate the authoritative Accounts-relevant architecture that predates the stream-based modernization framework into one baseline, so the ACC Validation Sprint has something concrete to validate against instead of scattered references across two generations of documentation.

## 2. Source Documents

| Source | Relevance |
|---|---|
| **ADR-018** — Account vs Payment Method | Directly authoritative. Defines Account/Payment Method split, credit card treatment. |
| **ADR-021** — Master Data vs Financial Objects | Directly authoritative. Places Account in Master Data (Manage); establishes Balance Engine as the owner of computed values (balance, outstanding, utilization) — Account itself never calculates its own balance. |
| **M008–M013** (Money module UX Bible, Aug 1 session) | Authoritative for screen-level intent: Accounts, Account Detail, Cash, Investments, Credit Cards — all owned by "Balance Engine" per that session's terminology. |
| ~~BP-001A (Core Transaction Engine)~~ | **Checked and excluded.** Confirmed scoped to Transactions (manual entry, CRUD, validation), not Accounts. Already fully covered by the TRX stream (Frozen). Included here only to record that it was checked, not silently assumed relevant. |
| Repository (`App.jsx`, current) | Ground truth for what's actually live, per Section 4. |
| Later governance references (Home, Budget, Program Dashboard) | Context only — none of these documents make independent Accounts architecture claims; they reference ACC's frozen status without adding to it. |

## 3. Architecture Already Frozen

From ADR-018:
- **Account answers "where does the money live"** (required); **Payment Method answers "how was it executed"** (optional, e.g. Debit Card/UPI/Net Banking/Cheque).
- **Credit cards are Accounts, not payment methods** — they carry balance, statement, due date, interest, EMI support.
- **Delete is permanent** for Arth 2.0 — no soft delete, no recycle bin, confirmed already matching live behavior.

From ADR-021:
- **Account is Master Data**, owned by Manage; referenced by Transactions, never owned by them.
- **Balance/outstanding/utilization are computed, not stored** — Account doesn't calculate its own balance; a Balance Engine does (the same "nouns vs. verbs" principle later reused in ADR-035 for Allocation).

From M008–M013 (screen intent, not frozen business rules — flagged as UX-level authority, one tier below ADR):
- Money's Accounts/Cash/Investments/Credit Cards screens all read from Balance Engine, never compute independently.
- Money shows **holdings/position only** — due dates and schedules are explicitly Outlook's responsibility, not Accounts/Money's.

## 4. Repository Validation Target

What this sprint needs to check the current repository against — two items already spot-checked while assembling this baseline, included as a preview:

- ❌ **UPI-as-separate-account-type: still drift.** ADR-018 froze UPI becoming a Payment Method on a bank account, not its own Account type. Current code still has `accounts.find(a=>a.type==="upi")` as live logic — the ADR's own text already flagged this migration as "genuinely open," so this isn't a surprise, but it's unresolved drift that Repository Validation should formally confirm and scope.
- ✅ **Credit limit field: resolved, not drift.** The Aug 1 session's M013 entry claimed CC accounts had no credit-limit field, showing "Not set" as an honest gap. Current code (line ~11045-11057) contains a self-documenting comment confirming this was a **mistaken assumption at the time** — `a.limit` was already a real, collected field — and the display bug has since been fixed to use it. Worth noting as a case where the earlier baseline was itself wrong, not just outdated.

Full Repository Validation (beyond these two spot-checks) is the sprint's Phase 1 work, not pre-empted here.

## 5. Production Validation Target

Per the scenarios already scoped for the ACC Validation Sprint: personal accounts, joint accounts, credit cards, cash wallets, loans, investments, closed accounts, hidden accounts, zero-balance accounts, multiple currencies (if applicable), account transfers, reconciled vs. unreconciled balances, billing cycles, historical imports. Requires real production data/exports — not attempted in this document.

## 6. Open Questions

- Is "Balance Engine" (M008-013's terminology) an actual code module, or only a UX-Bible label for "wherever balance gets computed"? Repository Validation should check whether this maps to real, consolidated code or is itself scattered — the same kind of question BUD-000 asked about "Budget" before finding five mechanisms instead of one.
- Does the UPI-account-migration gap (Section 4) block Financial Calendar's Billing Cycle period type (ADR-036), which reads credit card statement/due dates from Accounts? Needs checking during the sprint's Budget Dependency Review phase — not assumed either way here.
- Multi-currency support — no evidence found either confirming or ruling it out in any source document; genuinely unknown, not just unaddressed.

## 7. Success Criteria

- Repository Validation confirms or documents drift against Sections 3–4, with the UPI item formally scoped (fixed or explicitly deferred) rather than left as an ambient known-issue.
- Production Validation covers every scenario in Section 5 against real data.
- Budget Dependency Review answers whether Allocation Engine or Financial Calendar require any Accounts-side change before Budget engineering starts.
- One-page Sign-off issued: **ACC Approved** or **ACC Amendment Required** — no middle ground, per the sprint's own Phase 4 definition.

---

*This is the baseline. ACC Validation Sprint (Repository Validation → Production Validation → Budget Dependency Review → Sign-off) operates against this document, not against an assumed ACC-000 that never existed under this name.*
