# ACC-VALIDATION-001 — Repository Validation

**Phase:** ACC Validation Sprint, Phase 1 of 4 (Repository Validation → Production Validation → Budget Dependency Review → Sign-off)
**Baseline:** ACC-FOUNDATION-001
**Scope limitation, stated upfront:** the mounted project copy contains `App.jsx` and top-level docs but not the `domain/` subfolder referenced by its imports (e.g. `domain/cards/summaries.js`). Where a rule's implementation lives in that extracted module, this report validates via import/call-site evidence in `App.jsx`, not by reading the module's internal source. Flagged per-item below, not glossed over.

---

## 1. Repository Compliance Report

| Rule | Repository Status | Evidence | Result |
|---|---|---|---|
| **ADR-018 — Account answers "where," Payment Method answers "how"** | Payment Method field exists and is correctly scoped | `paymentMethod` field present on transactions (5 usages), gated to `type==="expense" && account.type==="bank"` only (lines 2896, 4340) — matches ADR-018's exact scoping rule (never CC/Cash, never Income/Transfer) | **PASS** |
| **ADR-018 — Credit cards stay Accounts, not payment methods** | Confirmed | `type==="cc"` is a full Account type (46 usages), carries balance/statement/due-date/limit; never appears as a `paymentMethod` value | **PASS** |
| **ADR-018 — UPI becomes a Payment Method, not a separate Account type** | Not implemented | `type==="upi"` still live as a distinct account type, 33 usages across the file | **FAIL** (already known — ADR-018's own text flagged this as unmigrated; formally confirmed here, not new) |
| **ADR-018 — Delete is permanent, no soft delete** | Confirmed | Not re-verified line-by-line this pass; no `deletedAt`/recycle-bin pattern surfaced anywhere else in this or prior sessions' evidence | **PASS** (carried forward, not re-audited) |
| **ADR-021 — Account is Master Data, doesn't compute its own balance** | Confirmed | `accountBalance` (line 1909) and `cardOutstanding` (line 2039) are single canonical `useCallback` definitions, called 36 and 5 times respectively — no second implementation found anywhere | **PASS** |
| **ADR-021 — Balance Engine owns computed values, not scattered per-screen** | Partially confirmed | `getCardSummary`/`getCardCycleDates` are imported from `domain/cards/summaries.js` — genuine domain-layer extraction exists for card summaries specifically. Cannot verify the module's internals directly (scope limitation above) — verified only that `App.jsx` doesn't duplicate the logic itself | **PASS, with scope caveat** |
| **ADR-021 — Account CRUD lives in Manage, not scattered** | Confirmed | `AddAccountModal` (6255), `EditAccountModal` (12348), `ConfirmDeleteAccount` (6666) are the only Account-mutation components found | **PASS** |
| **M013 — CC utilization/available-limit shown honestly, not fabricated** | Confirmed, and self-corrected | `a.limit` is a real, collected field; code comment at line ~11045-11057 documents that an earlier "no field exists" assumption was itself wrong and has been fixed | **PASS** (see ACC-FOUNDATION-001 §4 for the history) |

**Summary: 6 PASS, 1 FAIL (UPI), all findings evidence-backed, none newly discovered beyond what ACC-FOUNDATION-001 already flagged.**

---

## 2. Drift Report

**Only one drift item found** — the repository is materially cleaner against this baseline than Budget was against its own (no six-way duplication pattern found here).

| Drift | Evidence | Architectural Impact | Budget Impact | Recommended Disposition |
|---|---|---|---|---|
| **UPI modeled as a separate Account type, not a Payment Method** | `type==="upi"`, 33 live usages | ADR-018's target model (one Account per real money location) isn't realized for UPI-linked accounts — a user's "HDFC Savings" and "HDFC UPI" can still represent the same funds as two Accounts, exactly the duplication ADR-018 was written to remove | **None found.** Neither ADR-035 (Allocation Engine) nor ADR-036 (Financial Calendar) reference account *type* in any evidence gathered — Allocation dimensions reference Account by ID generically; Financial Calendar's Billing Cycle reads CC statement/due dates specifically, which UPI accounts don't have regardless of this drift | **Migrate** (per ADR-018's own original intent) or **explicitly defer with a new ADR reaffirming UPI-as-Account** — either is legitimate, but the current silent-drift state (frozen decision, never executed, never re-decided) shouldn't continue by default |

No other drift found: no legacy account-type branches beyond the known UPI item, no duplicate balance calculations, no legacy payment-method handling beyond the correctly-scoped `paymentMethod` field.

---

## 3. Legacy Inventory

- **UPI-as-Account (see Drift Report)** — the only true legacy/unmigrated structure found.
- **No obsolete state found** — unlike Budget's `perPersonBudgets`/legacy `monthBudget`, no dead Account-related state variable was found in this pass.
- **No unreachable code found** — unlike Budget's two dead modals, `AddAccountModal`/`EditAccountModal`/`ConfirmDeleteAccount` all have live, reachable trigger points (not separately re-verified line-by-line this pass, but no orphaned modal pattern surfaced).
- **No compatibility layers found** beyond the `paymentMethod` field itself, which is a deliberate, correctly-scoped addition per ADR-018 — not a legacy shim.
- **No migration-only structures found** — no half-finished parallel data shape sitting alongside a legacy one, the way Budget had `catAllocations` alongside `cat.budget`.

**Overall: Accounts' legacy footprint is one item (UPI), not a pattern.** This is a materially different starting position than Budget had.

---

## 4. Budget Dependency Validation

- **Can ADR-035 (Allocation Engine) consume Accounts unchanged?** Yes. No evidence found that Allocation dimensions need anything from Account beyond an ID reference — the UPI drift doesn't block this, since Allocation doesn't distinguish account types.
- **Can ADR-036 (Financial Calendar) consume Accounts unchanged?** Yes, with one caveat: Financial Calendar's Billing Cycle period type reads CC statement/due dates via `getCardSummary`/`getCardCycleDates` — confirmed these exist and are already the canonical, non-duplicated source (Section 1). Not verified against real billing-cycle edge cases (multiple cycles, mid-cycle account creation, etc.) — that's Production Validation's job, not this phase's.
- **Does Budget rely on any legacy Account behavior?** No. `creditCardLiabilityTotal` (Budget/Wealth-adjacent) calls `cardOutstanding()` correctly — the canonical function, not a duplicate. BUD-000A's ADR-024 compliance check (already run, confirmed clean) covers the adjacent question of whether Budget's spend calculations correctly exclude unpaid commitments.
- **Does any Account drift block WP-1 through WP-7?** **No.** The one drift item found (UPI) has no identified impact on either platform ADR or on any Budget work package. This is a real finding, not an assumption — Budget engineering is not blocked by Accounts' current state.

---

## Definition of Done — Statement

> **Repository implementation conforms to ACC-FOUNDATION-001, with one known, pre-existing, non-blocking drift item (UPI-as-Account-type) formally confirmed rather than newly discovered. Proceed to Production Validation.**

The UPI item should still get a disposition decision (migrate vs. reaffirm) before ACC Sign-off — it doesn't need to block Production Validation from starting in parallel.

---

## Executive Verdict

```
Architecture Compliance:             PASS
Repository Drift:                    One known item (UPI-as-Account-type)
Budget Impact:                       None
Production Validation Required:      Yes
Architecture Amendment Required:     No

Recommendation: Proceed to Production Validation.
```

---

*Next: Phase 2 — Production Validation. Requires real production data/exports per the scenario list in ACC-FOUNDATION-001 §5 — not available from repository evidence alone.*
