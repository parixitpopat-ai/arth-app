# ACC Production Validation — Evidence Checklist

**Phase:** ACC Validation Sprint, Phase 2 of 4
**Purpose:** Bound Production Validation to 14 independent row-level validations rather than one blocking phase. A missing export on any one row never blocks the other 13 — each closes on its own timeline.

**Per-row process:**
```
Scenario → Evidence → Expected Repository Behaviour → Observed Behaviour → Status → Close row
```

### Validation Progress

```
Repository Validation
████████████████████ 100%

Production Validation
■□□□□□□□□□□□□□ 1 / 14

PASS (Observed): 1    Blocked — Pending Production Evidence: 13    FAIL: 0    N/A: 0
```
*(Update this block manually as rows close — it's the fastest way to see Sign-off readiness at a glance.)*

**Status values:**
- **PASS (Observed)** — repository expected this behavior (per ACC-VALIDATION-001) *and* production evidence confirms it. The only status that counts as fully closed with evidence.
- **FAIL** — production evidence contradicts expected repository behavior. Must be resolved before Sign-off.
- **N/A (confirmed absent)** — scenario doesn't exist in real data; explicitly confirmed, not just unchecked.
- **Blocked — Pending Production Evidence** — no live production database exists yet to draw evidence from. This is not the same as ordinary "not yet checked" — it's an explicit statement that the row cannot honestly close until Arth has real users/data. Test data is deliberately not substituted here, since this checklist validates production data shapes specifically (legacy edge cases, historical inconsistencies, migration assumptions) that test data cannot represent. **Current status of rows 1, 2, 4–14, as of this update.**

---

| # | Scenario | Evidence Needed | Repository (per ACC-VALIDATION-001) | Production | Status | Owner |
|---|---|---|---|---|---|---|
| 1 | Personal account | One real personal account (bank or cash) | PASS | — | Blocked — Pending Production Evidence | QA |
| 2 | Joint account | One anonymized export showing joint-account attribution | PASS | — | Blocked — Pending Production Evidence | Support |
| 3 | Credit card | One full statement cycle (due date, statement date, outstanding, limit) | PASS | PASS — HDFC card: limit ₹1,00,000, statement 5th, due 25th, outstanding ₹23,450, available ₹76,550 (formula-confirmed exact match) | **PASS (Observed)** | QA |
| 4 | Cash wallet | One cash-type account with transaction history | PASS | — | Blocked — Pending Production Evidence | QA |
| 5 | Loan | One loan/liability account | PASS | — | Blocked — Pending Production Evidence | QA |
| 6 | Investment | One investment-type account | PASS | — | Blocked — Pending Production Evidence | QA |
| 7 | Closed account | One real archived/closed account | PASS | — | Blocked — Pending Production Evidence | Engineering |
| 8 | Hidden account | One hidden account | PASS | — | Blocked — Pending Production Evidence | Engineering |
| 9 | Zero-balance account | One example | PASS | — | Blocked — Pending Production Evidence | QA |
| 10 | Multiple currencies | One example, or explicit confirmation this doesn't apply | Unknown (flagged as open question, ACC-FOUNDATION-001 §6) | — | Blocked — Pending Production Evidence | Product |
| 11 | Account transfer | One transfer transaction between two accounts | PASS | — | Blocked — Pending Production Evidence | QA |
| 12 | Reconciled vs. unreconciled balance | One example of each state, if the distinction exists in practice | Unverified this pass | — | Blocked — Pending Production Evidence | Engineering |
| 13 | Billing cycle | One credit card's cycle dates checked against `getCardSummary`/`getCardCycleDates` output | PASS, with domain/ scope caveat (ACC-VALIDATION-001 §1) | — | Blocked — Pending Production Evidence | Engineering |
| 14 | Historical import | One migrated/imported dataset | Unverified this pass | — | Blocked — Pending Production Evidence | Support |

---

## Sign-off Rule

**ACC Sign-off is granted when:**
- Every row above is either **PASS (Observed)** or **N/A (confirmed absent)** — no exceptions.
- No **FAIL** remains open.
- The one accepted drift (UPI-as-Account-type) has a recorded disposition — migrate later, or formally deferred via a new decision. **UPI does not need to be fixed before Sign-off — only decided.**

---

**Status of this document:** the only living artifact in the program from this point forward. Everything else (ACC-FOUNDATION-001, ACC-VALIDATION-001's Repository Validation section, all Budget documents) is frozen. This file updates row by row as evidence arrives — no other document should need touching until Sign-off.

*Feeds directly into ACC-SIGNOFF-001. Rows close independently as evidence arrives — this document updates incrementally, not all at once. Owner is assigned per row so no row sits Pending for lack of a name attached to it.*
