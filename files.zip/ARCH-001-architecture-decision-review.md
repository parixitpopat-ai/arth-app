# ARCH-001 — Architecture Decision Review

**Status:** Approved
**Type:** Temporary decision document. Closes once ADR-035 and ADR-036 are approved — this is not a standing architecture reference (see `ARTH-001`, unchanged, for that).
**Purpose:** Review and validate the platform-architecture discoveries surfaced by BUD-000A (Budget module audit). Not a repository audit. Not an implementation plan. No code changes or module redesigns are in scope.
**Input:** `BUD-000A-architectural-tensions-adr-impact-review.md`, `BUD-000A-decision-record.md`

---

## 1. Background

The BUD-000 module audit (Repository Audit → ADR Review, all frozen) set out to determine what the Budget domain should own. In doing so it surfaced a question bigger than Budget: what "Allocation" means across Arth, and who should own it and the Fiscal Calendar concept it depends on. BUD-000A escalated this as required — a module audit is permitted to identify architectural ambiguity but not to resolve it. This document is that resolution.

## 2. Decisions Under Review

### 2.1 Hybrid Allocation Model — **Approved**

"Allocation" names two distinct concepts, not one:

- **Financial Allocation (Planning)** — hierarchical, reconciling. Annual Budget → Category → Monthly value; the parts sum to the whole. Owned by Budget.
- **Analytical Allocation (Attribution)** — independent, non-reconciling dimensions (Category, Person, Trip, Goal, Project, Liability, Account). One transaction can attribute fully to several dimensions at once with no sum requirement.

**Evidence basis (from BUD-000A):** the repository schema already draws this exact line for every dimension that currently has both — `cat.budget`/`p.spendBudget` (planning, target amounts, live on the owning entity) versus `catAllocations`/`t.people` (attribution, live only inside a transaction, describing what happened). The Hybrid model formalizes a distinction the codebase already implements informally.

**Consequence:** "Allocation" is retired as an unqualified term in future architecture documents. Use **Budget Allocation** (or **Financial Allocation**) for the planning concept and **Allocation** / **Attribution** for the analytical concept, consistently, starting with ADR-035.

### 2.2 Allocation as Shared Platform Capability — **Approved**

Not owned by Budget. Not owned by Transactions. Transactions produce facts; the Allocation capability maps facts onto dimensions; Budget, Reports, Goals, AI, and Forecasting consume it independently. Architecturally parallel to Ledger's existing role in the platform.

**Evidence basis:** ADR-021's existing "nouns vs. verbs" framework already establishes that behavior (a verb — paid, split, forecast, analysed) belongs to a named Engine, never to Manage or to a single feature module. Allocation is a verb in that taxonomy. This gives the decision real architectural precedent rather than treating it as a new pattern invented for Budget's sake.

### 2.3 Financial Calendar as Shared Platform Capability — **Approved**

Not owned by Budget. Multiple current and future consumers (Budget, Goals, Investments, Reports, Tax, Forecasting, recurring payments) all need period/FY/quarter normalization.

**Evidence basis:** the repository currently hardcodes the April 1 fiscal-year start in at least two unrelated, duplicated locations (People page's group-spend calculation, BudgetPage's own FY label) with no shared source — the exact failure pattern (silent duplication, no canonical owner) that BUD-000's Mutation Census found six times over for the monthly-budget formula. Owning the calendar inside Budget would repeat that pattern at platform scale instead of fixing it once.

## 3. Impact on Existing ADRs

| ADR | Impact |
|---|---|
| **ADR-025, Rule 2** | Not contradicted. Correctly describes Financial Allocation for the Person/Group case it addresses; it simply doesn't speak to Category, Trip, Goal, Project, or Liability. Stands as-is under the Hybrid model — no amendment required. |
| **ADR-024** | No conflict; confirmed compliant during BUD-000A's compliance check. One naming note carried forward: BUD-000's "Budget Forecast" concept must be named distinctly from ADR-024's frozen "Forecast Status" (different questions — budget adherence vs. cash-flow survival) when ADR-035/036 are drafted. |
| **ADR-021** | Reinforced, not amended — provides the precedent this review relies on for treating Allocation as an Engine-layer capability. |
| **ADR-008** | Reinforced — its field-priority-resolution discipline (resolve to one canonical field, don't sum legacy duplicates) is the relevant precedent for how `catAllocations`/`t.people` should generalize into the platform Allocation capability. |

No existing ADR requires amendment as a result of this review.

## 4. Approval

1. Hybrid Allocation Model — **Approved**
2. Allocation as a shared platform capability — **Approved**
3. Financial Calendar as a shared platform capability — **Approved**
4. Authorization to draft **ADR-035 — Allocation Engine** and **ADR-036 — Financial Calendar** — **Approved**

## 5. What Happens Next

- ADR-035 and ADR-036 may now be drafted, per the scope defined in `BUD-000A-decision-record.md`.
- BUD-001 (Budget Modernization Plan) remains blocked until both ADRs are approved.
- `ARTH-001` (Core Domain Architecture handbook) remains untouched and deferred — this review does not pull it forward. Once ARTH-001 is eventually written, the decisions in this document should be folded into its Canonical Vocabulary and Platform Capabilities sections; ARCH-001 itself closes at that point and is not maintained further.

---

**Status: Closed pending ADR-035/036 completion.** No further action under ARCH-001 until both ADRs are drafted and approved.
