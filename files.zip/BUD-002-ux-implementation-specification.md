# BUD-002 — UX & Implementation Specification

**Status:** Draft
**Depends on:** BUD-001 (Modernization Plan), BUD-001A (Implementation Readiness — approved), ADR-035, ADR-036
**Supersedes:** the separate BUD-002/BUD-003 split originally planned; this single document carries both UX and implementation scope, per your instruction that for Budget the two are inseparable.
**Note on wireframes:** `budget-restructure-mockup.html` (project files) already contains real, built wireframes for two screens — Budget top-level and Budget → Insights (month list). Those are used directly below rather than re-described. Every other screen in this spec is new and has no existing visual mockup — Part A describes their required structure, states, and journeys at a specification level; producing actual pixel mockups for them is a design task that should happen before WP-4 engineering starts, not a gap this document silently fills in.

---

## Part A — UX

### Navigation

Unchanged at the top level — Budget stays a drawer/tab entry, consistent with the existing app shell. Confirmed from the existing mockup: Budget's top-level screen has three sub-tabs — **Overview**, **Insights**, **Budgets** — this structure is retained, not redesigned, since BUD-000's audit found no evidence it was the source of the domain problems (the problems were in ownership and duplication, not navigation).

### Screen Hierarchy

```
Budget (top-level)
├── Overview          — household Planning Allocation summary (existing mockup, reused)
├── Insights           — month-by-month spend history (existing mockup, reused)
│   ├── Person view    — per-person Planning Allocation + Attribution (segmented control, existing)
│   ├── Month view     — existing, reused
│   └── Summary view   — existing, reused
└── Budgets            — NEW: the Planning Allocation editor
    ├── Household editor
    ├── Category editor list
    ├── Person editor list
    └── Group editor list
```

**New screen required:** the Planning Allocation editor under "Budgets." This is the direct replacement for the two dead modals found in BUD-000 Phase 3 (`editingMonthBudget`, `budgetOverrideMonth`) — this spec is where that gap actually gets closed, not just documented.

### User Journeys

1. **Set a household budget for a fiscal year.** Budgets tab → Household editor → enter annual amount → confirm. Writes a Planning Allocation, Household dimension, Fiscal Year period (per ADR-035/036).
2. **Override a specific month's household budget.** Insights → Month view → tap a month card (existing interaction, confirmed in mockup: tapping "Jul 26" expands category breakdown) → **new:** an edit affordance on the expanded card, writing a Planning Allocation override, Calendar Month period. This is the one new interaction the existing mockup's month card needs — it currently only expands to show category spend, it doesn't yet offer editing.
3. **Allocate a category budget.** Budgets tab → Category editor list → select category → enter amount → confirm. Writes a Planning Allocation, Category dimension.
4. **View a person's spend and budget together.** Insights → Person view (segmented control, existing) → shows Planning Allocation (target) alongside Attribution-derived actual spend for that person, side by side — this is the Variance read-model, computed, not stored.
5. **Close a period.** Budgets tab → Household editor → explicit "close month" action once a Financial Calendar period has ended. Not present in the existing mockup at all — new interaction, tied to Aggregate Identification's "Period needs a lifecycle status" finding (BUD-000 Phase 6).

### States

Every screen above needs, at minimum:
- **Empty** — no Planning Allocation set yet for a dimension/period (distinct from a Planning Allocation of ₹0, which is a deliberate value, not an empty state — this distinction matters given ADR-021's Progressive Enrichment Rule precedent: missing should never silently render as zero).
- **Loading** — while the Allocation Engine query resolves; relevant given WP-1 introduces a new query layer between UI and data that didn't exist before.
- **Error** — Allocation Engine query or write failure; must not silently fall back to a stale cached value without indicating staleness.
- **Populated** — the normal case, as shown in the existing mockup.

### Accessibility

No new accessibility requirements beyond the app's existing baseline — this spec doesn't introduce new interaction patterns (drag/gesture-based allocation editing, for example, is explicitly not proposed) that would need separate accessibility design work.

---

## Part B — Functional Behaviour

| Interaction | Behavior |
|---|---|
| **Create Budget (household)** | User enters an annual amount for a Fiscal Year. Writes one Planning Allocation (Household, Fiscal Year period). |
| **Edit Budget (household)** | Updates the existing Planning Allocation for that Fiscal Year, or creates a Calendar Month override if editing a specific month (two different targets, same editor — mirrors ADR-035's Planning Allocation model, not two separate mechanisms as today). |
| **Allocate Category** | Writes a Planning Allocation, Category dimension, no period-override layer initially (matches current `cat.budget`'s flat-only shape, per BUD-000 Phase 4's CBR-BUD-10 finding — this spec does not introduce category-level month overrides that don't exist today; that would be scope creep beyond migration). |
| **Allocate Person / Group** | Writes a Planning Allocation, Person or Group dimension, with Calendar Month override support (matches today's `spendBudgetOverrides`/`manualLimitOverrides` capability — preserved, not reduced). |
| **Forecast** | Read-only. Computed from Planning Allocations + Attribution-derived spend-to-date + Financial Calendar period boundaries. Never writes anything — consistent with Aggregate Identification's "never store Forecast" rule. |
| **Carry Forward** | Toggled at the household Policy level (per BUD-001's migration mapping — `budgetCarryForward` stays Budget-owned, not an Allocation Engine concept). When on, affects the Forecast/Variance read-model computation for the following period; does not write a new Planning Allocation. |
| **Close Period** | Transitions a Financial Calendar period referenced by the household Budget Period entity from open to closed (per Aggregate Identification's Budget Period lifecycle finding). Once closed, no further Planning Allocation writes are accepted for that period — this is the concrete mechanism that makes "closed Period = historical record" (BUD-000's replacement for the rejected Budget Snapshot aggregate) actually true. |

---

## Part C — Platform Integration

| Screen | Uses | Produces |
|---|---|---|
| **Overview** | Allocation Engine (Planning Allocation query), Financial Calendar (current FY period) | — (read-only) |
| **Insights → Month view** | Allocation Engine (Planning Allocation + Attribution query), Financial Calendar (Calendar Month periods), Transactions (via Attribution) | — (read-only) |
| **Insights → Person view** | Allocation Engine (Person-dimension Planning Allocation + Attribution), People (dimension identity) | — (read-only) |
| **Insights → Summary view** | Allocation Engine (cross-dimension query), Categories (dimension identity) | — (read-only) |
| **Budgets → Household editor** | Financial Calendar (Fiscal Year, Calendar Month periods) | Planning Allocation (Household), Budget Policy update |
| **Budgets → Category editor** | Categories (dimension identity) | Planning Allocation (Category) |
| **Budgets → Person/Group editor** | People, Groups (dimension identity) | Planning Allocation (Person/Group) |
| **Close Period action** | Financial Calendar | Budget Period status change (open → closed) |

Notifications is a consumer, not listed per-screen — Budget Alert threshold logic (Aggregate Identification's shared boundary) emits events that Notifications reads independently of which screen triggered the underlying Planning Allocation or Attribution change.

---

## Part D — Engineering Notes

**Component ownership:** BudgetPage (existing component, App.jsx ~12451) is rebuilt, not replaced wholesale — its "Overview"/"Insights"/"Budgets" tab structure is retained per the navigation decision above; its internal implementation of variance/health/forecast (currently inline, duplicated against Home/OutlookPage per BUD-000 Phase 2/3) is replaced with calls to the Allocation Engine and Financial Calendar. The two dead modals (`editingMonthBudget`, `budgetOverrideMonth`) are deleted outright, not refactored — WP-4's new Household editor replaces both.

**APIs:** per ADR-035 §7 and ADR-036 §7 — conceptual signatures only, final shapes are WP-1/WP-2 implementation detail, not fixed by this spec.

**Migration notes:** this spec assumes WP-1/WP-2/WP-3 (Allocation Engine, Financial Calendar, Storage Migration) are complete before WP-4 UI work begins reading from them, per BUD-001's sequencing. If WP-4 needs to start before WP-3 fully completes for all users, it must read through the Phase 5 ("Switch reads") state defined in BUD-001 Section 6 — never read legacy fields directly, which would reintroduce the duplication this program exists to remove.

**Performance considerations:** the Insights → Month view (existing mockup) already renders a list of month cards with an expand-to-category-breakdown interaction; under the new model this becomes an Allocation Engine query per expansion rather than a local computation over already-loaded transactions. Needs a caching/prefetch strategy considered during WP-4, not assumed to be free.

**Telemetry:** not currently instrumented anywhere in Budget per BUD-000's audit (no telemetry calls found in BudgetPage during any phase of the audit) — this spec doesn't invent new telemetry requirements beyond flagging that none exist today; a decision on whether to add any is a product call outside this document's scope.

**Feature flags:** given BUD-001's phased migration (Section 6, seven phases), WP-4's UI changes should be flaggable independently of WP-3's storage migration completing — allows the new Household editor to ship and be tested even while dual-write/validation is still in progress for the broader user base.

---

## Part E — Acceptance Criteria (per screen)

- **Overview:** displays the correct Fiscal Year Planning Allocation and current spend, sourced entirely from Allocation Engine + Financial Calendar queries — no local duplicate calculation (directly closes the six-duplicate-read finding from BUD-000 Phase 3 for the Overview screen specifically).
- **Insights → Month view:** existing card/expand interaction preserved exactly as in the current mockup; underlying data source switched to Allocation Engine without visible behavior change to the user.
- **Insights → Person view:** Planning Allocation and Attribution-derived actual spend shown together per person; matches pre-migration numbers exactly for a validation sample (ties to BUD-001 Phase 4 — Validate).
- **Budgets → Household editor:** replaces both dead modals; reachable from the UI (this is the concrete test that finally closes BUD-000 Phase 3's "permanently unreachable" finding); writes a correct Planning Allocation on save.
- **Budgets → Category/Person/Group editors:** each writes a correctly-dimensioned Planning Allocation; Category editor does not introduce a month-override capability that doesn't exist in the current product (scope discipline, per Part B).
- **Close Period:** once closed, further Planning Allocation write attempts for that period are rejected, verified by an explicit test, not just relied upon informally.

---

**Next:** Engineering (WP-1 → WP-2 → WP-3 → WP-4), per BUD-001A's approval. No further planning documents precede implementation.
