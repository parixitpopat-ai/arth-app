# BUD-CLOSE-001 — Budget Modernization Closure

**Version: Budget Modernization v1.0 (Design Baseline)**
**Status:** Design stream closed. Engineering not yet started (blocked on ACC Validation).

Engineering references this baseline as **"implemented against Budget Modernization v1.0"** rather than citing individual documents. Any future addition (Event Dimension, Vehicle Dimension, Advanced Forecasting, or any other item from the Deferred list below) constitutes Budget Modernization v2.0 when it's scoped — this baseline is not edited retroactively to absorb it.

---

## Scope Completed

BUD-000 · BUD-000A · ARCH-001 · ADR-035 · ADR-036 · BUD-001 · BUD-001A · BUD-002 · BUD-003

## Architecture Decisions (frozen)

- **ADR-035** — Allocation Engine (Hybrid model: Planning Allocation + Analytical Attribution, platform capability)
- **ADR-036** — Financial Calendar (platform capability)

No prior ADR amended. ADR-025 Rule 2 stands as-is, refined in scope by ADR-035, not contradicted.

**Platform capabilities established by this stream** — the most significant outcome beyond Budget itself: the **Allocation Engine** and **Financial Calendar** are now part of Arth's platform architecture, available to every future module (Goals, Trips, Reports, Investments, AI) without redoing this discovery work. This is recorded here as part of the project's architectural history, not just as a Budget dependency.

## Canonical References for v1.0

- **WP list:** WP-1 through WP-7 (BUD-003) — the only executable engineering work in this baseline.
- **DS list:** DS-1 through DS-9 (BUD-003) — approved future work, explicitly excluded from v1.0.

## Deferred Items (become Budget Modernization v2.0 candidates, not v1.0 scope)

- ADR-035A Addendum (Event/Vehicle dimension promotion, if ever required)
- UX-001 — Planning Allocation Editor design (owned by Product/Design)
- DS-1 Reports Integration
- DS-2 AI Integration
- DS-3 Event Dimension
- DS-4 Vehicle Dimension
- DS-5 Telemetry
- DS-6 Category Month Overrides
- DS-7 Budget Templates
- DS-8 Budget Cloning
- DS-9 Advanced Forecasting (beyond Release 1's Budget Projection)

## Entry Criteria for Engineering

- [ ] ACC Validation complete
- [ ] ACC signed off
- [ ] Budget work packages approved (WP-1 – WP-7, BUD-003)

## Exit Criteria for Release 1

- [ ] Budget Release complete
- [ ] Legacy code removed (WP-6)
- [ ] Migration complete (WP-3, all seven phases)
- [ ] Rollback window closed

---

**This document is the index.** For detail, see the nine artifacts listed under Scope Completed — nothing in this closure record substitutes for them, it only points to them.
