# WP-1 — Allocation Engine Integration: Task Decomposition

**Purpose:** Planning-level breakdown only. No code written here. Can start immediately — does not depend on ACC Sign-off, per BUD-000A's Budget Dependency Validation (Allocation Engine consumes Accounts unchanged).

---

### TASK-1 — Identify every `cat.budget` consumer

Already inventoried during BUD-000 (Phase 3, Mutation Census) — not re-audited here, just carried forward as engineering input:
- Read sites: Categories page bar rendering, Settings category editor, BudgetPage's "Where Money Went" panel (~line 12556), monthly breakdown (~12984)
- Write sites: Settings only — category creation (~12291) and edit (~12238)
- **Single writer confirmed** — this consumer set is low-risk for the adapter.

### TASK-2 — Identify every `p.spendBudget` / `spendBudgetOverrides` consumer

- Read sites: `budgetAlerts` generator (AppContent, ~1732), BudgetPage's per-person rows (~12841, ~12936, ~12940)
- Write sites: People page (creation wizard, ~8744; edit, ~15090), BudgetPage's override commit (~12476)
- **Two writers, cleanly separated** (base value vs. month override) — adapter needs to preserve that separation, not collapse it.

### TASK-3 — Identify every `g.manualLimit` / `manualLimitOverrides` consumer

- Read sites: People page group cards (~9290, ~10005), BudgetPage (~13015)
- Write sites: People page (creation wizard ~8753, edit ~9389), BudgetPage's override commit (~12482)
- Same two-writer pattern as person budgets — same adapter shape should work for both.

### TASK-4 — Identify every `monthOverrides` / `annualBudget` consumer

This is the highest-risk task — six independent duplicate reads found in BUD-000 (Phase 3):
- AppContent top-level (~2355, ~2397)
- Home (~7628, ~10852)
- OutlookPage (~10644)
- BudgetPage (~12495, ~12841)
- **Write sites:** BudgetPage only (~12492-93 for annual/lastFY target, plus the two *dead* modals at ~15991/16003 that never fire — see BUD-000 Phase 3)
- **Task output should include:** a decision on whether the adapter replaces all six reads in one PR or migrates them incrementally with a temporary shared helper — this is a real sequencing question for whoever picks up TASK-4, not decided here.

### TASK-5 — Design Allocation API adapter

Translates today's four field-shapes (Task 1-4) into calls against ADR-035's conceptual API (`getPlanningAllocation`, `getAttributedTotal`). Output: an interface spec engineers can code against, plus a decision on whether the dead-modal replacement (WP-4 territory) is coordinated with this task or kept fully separate.

### TASK-6 — Write regression tests

Per BUD-001's Acceptance Criteria (WP-1): automated tests covering ADR-035 Section 6's invariants (reconciliation, non-reconciliation, orthogonality) — following the TRX-002A precedent (Node's built-in test runner, first automated tests in the project's history) rather than inventing a new testing approach.

### TASK-7 — Migration spike

A time-boxed technical spike (not the full WP-3 migration) to validate that the two-phase-write pattern from BUD-001 Section 6 (Create → Populate, without touching legacy fields) is mechanically sound against one real dimension (e.g. Category, the lowest-risk one per Task 1) before committing to it for all four.

---

**Sequencing note:** TASK-1 through TASK-4 can run in parallel (independent consumer inventories). TASK-5 depends on all four. TASK-6 can start once TASK-5's interface spec exists, in parallel with TASK-7.

---

## WP-1 Exit Criteria (PR Checklist)

```
□ ADR-035 followed
□ ADR-036 followed (where periods are touched)
□ No duplicated allocation logic introduced (the six-read pattern from
  Task 4 must not simply be re-created against the new API)
□ Repository tests pass (Task 6)
□ Migration compatibility maintained (legacy fields untouched until
  WP-3's own gated deletion step — WP-1 does not delete anything)
□ No Budget regression (existing BudgetPage/Home/OutlookPage behavior
  unchanged for end users during this work package)
□ Code review completed
```

This checklist gates every PR under WP-1, not just the final one.
