# Arth Modernization — Program Dashboard

**Last updated:** at close of Budget Modernization v1.0

| Stream | Status | Next Milestone |
|---|---|---|
| Transactions | ✅ Complete | None |
| Accounts | See progress meter below | ACC Sign-off |
| Home | ✅ Complete | None |
| Budget | 🟢 Design Frozen (v1.0) | Engineering (WP-1 → WP-7, blocked on ACC Sign-off) |
| Trips | ⏳ Not Started | TRIP-000 |
| Goals | ⏳ Not Started | GOAL-000 |
| Reports | ⏳ Not Started | REPORT-000 |
| Investments | ⏳ Not Started | INVEST-000 |
| Core Architecture | ⏳ Deferred | ARTH-001 |

**Platform capabilities established (available to all streams above, not just Budget):**
- Allocation Engine (ADR-035)
- Financial Calendar (ADR-036)

**Governance rule in effect:** frozen streams (Transactions, Home, Budget v1.0) are edit-locked — touched only via Engineering work packages, Bug tickets, or a Change Request producing a new version. No stream reopens for redesign without one of those three triggers.

**Current focus:** ACC Validation Sprint — Phase 2, Production Validation.

**Accounts — Validation Progress:**
```
Repository Validation
████████████████████ 100%

Production Validation
□□□□□□□□□□□□□□ 0 / 14
```

**Sign-off target defined (not yet written):**
```
ACC-SIGNOFF-001
Inputs:  ACC-FOUNDATION-001, ACC-VALIDATION-001, Production Validation evidence
Output:  Approved  |  Amendment Required
```

**Living document:** `ACC-production-validation-checklist.md` is the only active artifact in the program. Everything else is frozen — update that file, not this dashboard, as rows close; sync this progress meter only when Sign-off is reached.

---

*This dashboard is the index across streams. For detail on any stream, see that stream's own document set (e.g. Budget: BUD-000 through BUD-CLOSE-001).*
