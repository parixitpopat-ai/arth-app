# Arth — Changelog

Format: newest first. One entry per shipped batch, not per individual
fix — see `SCREEN_ARCHITECTURE.md` for per-screen implementation detail.

## v0.3.1 — Pass 3B: idGenerator, currency, csv

Dependency map built first, per the standing rule established after Pass
3A's discovery. One finding worth noting: no `validators.js` content
actually exists in this codebase — checked, and there's no distinct "is
this valid" logic beyond money parsing, so those three functions went
into `currency.js` instead of forcing an empty/mismatched fourth file.

- `src/helpers/idGenerator.js` — `genId`. Lowest risk, zero dependencies,
  extracted first as planned.
- `src/helpers/currency.js` — `parseMoney`, `cleanMoneyInput`,
  `nearlyEqualMoney` (absorbs what would have been `validators.js`).
- `src/reports/csv.js` — generic CSV mechanics only (`rowsToCsvString`,
  `downloadCsvFile`). Confirmed by reading the original code that it mixed
  CSV plumbing with transaction-column knowledge in one handler; only the
  plumbing moved. Timeline's bulk-export handler still owns which columns
  and how to read them off a transaction — that's business logic, not CSV
  logic.

Folder structure now follows domain-first naming (Rule 11): `helpers/`
for generic utilities, `reports/` for reporting-domain code, `constants/`
for data and domain config. Not a flat `helpers/` dumping ground.

Validated by full bundling, zero circular imports (all three new modules
are leaf files — no imports of their own).

`App.jsx`: 15,494 → 15,477 lines.

No breaking changes. No behavior changes — pure code motion.

## v0.3.0 — Pass 3A: zero-dependency extraction

First real crack in the monolith. Extracted, with a full dependency map
built before touching anything (see `DEPENDENCY_MAP.md`):
- `src/constants/theme.js` — DARK, LIGHT, PALETTE
- `src/helpers/dateHelpers.js` — todayStr, addDaysToDateStr,
  getPeriodEffectiveEnd, daysInMonth, daysLeft, getMonthBounds,
  getPreviousMonthKey
- `src/helpers/textHelpers.js` — normalizeVendorText (new file, small but
  genuinely separate — a matching utility, not a formatter)
- `src/constants/appConstants.js` — all pure data constants (person/group
  modules, category/account/investment/liability/asset type lists,
  default categories/accounts, vendor rules, cloud schema version)
- `src/constants/investmentConfig.js` — new file, split out after
  discovering `formatInvestmentMetric` needed `getInvestmentMetricConfig`,
  which is investment domain config, not a pure formatter. Didn't force it
  into `formatters.js` just to hit a target file count.
- `src/helpers/formatters.js` — narrower than originally planned;
  `formatShortDate` and everything touching it stayed in `App.jsx` because
  it's part of a real, self-contained date-parsing chain
  (`toDateOnly` → `normalizeToIsoDate` → `extractDateFromText`/`buildIsoDate`)
  that deserves its own pass, not to be rushed in.

Validated by actual bundling (`esbuild --bundle`, resolving real cross-file
imports), not just single-file syntax checking — this catches wrong paths
and mismatched export names, which single-file checks can't.

`App.jsx`: 15,740 → 15,494 lines.

No breaking changes. No behavior changes — pure code motion.

## v0.2.0 — Timeline Complete

**✅ Timeline** (Screen 6) — first screen to reach full spec completion.
- Swipe actions (Favourite / Repeat / Share / Delete)
- Date grouping (Today / Yesterday / Earlier This Week / This Month / Older)
  with sticky headers and per-bucket spend totals
- Bulk select, bulk delete, bulk category change, CSV export
- Confirmed pre-existing: search, advanced filters (more extensive than
  initially assessed)

No breaking changes. No new required fields on the transaction object.

## v0.1.4 — Add Transaction rebuilt

**✅ Add Transaction** (Screen 5) — the true 3-tap flow: Amount → "What was
it?" (live category detection, reusing Add Transaction's existing
history-match + keyword-rule logic) → Confirm → direct save.
- New, independently-reviewable save path for simple expenses (~15-line
  transaction object) — does not touch or duplicate the existing 2,653-line
  full form, which remains available via "Need to split, tag a person, or
  add details?"
- FAB and Home's Quick Actions "Expense" button both route through it

No breaking changes.

## v0.1.3 — Home Dashboard, Goals, Events

**✅ Home Dashboard** — feature-complete against real data.
- Financial Health Score (formula-based: Savings Rate 25, Bills On Time 20,
  Budget Adherence 15, Emergency Fund 15, Debt Ratio 10, Net Worth Growth 10,
  Consistency 5), with breakdown modal
- Time-of-day greeting, consolidated Action Centre, Quick Actions grid,
  AI Insight (single card, rule-based, category spend swing vs last month)
- Goals and Events cards — hidden entirely when there's no data, not faked

**✅ Goals** (Screen 10) — new module, built from scratch.
- Manual or account-auto-tracked progress, target date, completion
- Wired into cloud sync from creation (all four sync points)

**Events** (Screen 11) — enhanced, not rebuilt.
- Turned out to already support expense linking, spend totals, and people
  (more complete than initially assessed)
- Added: Budget field with progress tracking and over-budget warnings

**Fixed:** group/person spend double-count — a transaction tagged to both a
group and split among individuals was counted in both totals independently.
Individual "spent_on" attribution now skips when a `groupId` is also
present, since the group total already accounts for that money.

No breaking changes.

## v0.1.2 — Nav shell, rebrand, cloud sync hardening

- Bottom nav rebuilt: Home / Timeline / ➕ (FAB) / Money / Me — Bills moved
  to the drawer
- Full rebrand: gold/blue → green primary accent (base theme + every
  session-added blue instance, including the PIN and error screens that
  were missed on the first pass)
- Daily wealth/budget snapshot recorder — silent, no UI yet, feeds the
  Financial Health Score's Net Worth Growth component
- Cloud sync: fixed stale snapshot (missing `useMemo` deps), added
  pull-on-tab-focus, and — most importantly — pull no longer silently
  overwrites local data that looks newer than the cloud copy; a backup is
  taken before every overwrite regardless

## v0.1.1 — Bug fixes, Budget/People/Bills modules

- Fixed: membership grace period (was baked into dates, now separate),
  person budget doubling (attribute-tagged expenses counted twice),
  duplicate biller shells (root cause + auto-cleanup of existing duplicates)
- Budget: Monthly Dashboard, per-month person/group overrides, Annual
  Person View, "Can I Afford This?" calculator
- People/Groups: modules/capabilities system replacing hardcoded type
  checks, Person Dashboard rebuild, 3-step Add Person/Group wizards
- Bills: full reorder (Needs Attention/Pinned/All), Connection Dashboard,
  Analytics, Units/Meter fields, Credit Cards folded into the Biller
  hierarchy, shell/account editing

## v0.1.0 — Baseline

Existing app at the start of this working session: Bills v1, core
Transaction/Account/Budget engines, People & Groups, Memberships.
